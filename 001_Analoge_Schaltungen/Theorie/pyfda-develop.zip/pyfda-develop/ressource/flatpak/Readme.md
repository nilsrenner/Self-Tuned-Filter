Checkout the [pyfda flathub repository](https://github.com/flathub/com.github.chipmuenk.pyfda) for the flatpak manifest
