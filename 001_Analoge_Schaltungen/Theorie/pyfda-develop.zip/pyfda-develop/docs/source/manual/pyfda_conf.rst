.. include:: ../../../pyfda/libs/pyfda_template.conf
   :literal:
