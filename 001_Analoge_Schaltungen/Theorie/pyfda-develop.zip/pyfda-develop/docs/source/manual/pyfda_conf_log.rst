.. include:: ../../../pyfda/libs/pyfda_log_template.conf
   :literal:
