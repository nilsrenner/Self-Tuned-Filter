Package filter_widgets
======================

Package providing various algorithms for FIR and IIR filter design.

.. automodule:: pyfda.filter_widgets

