pyfda.plot\_widgets package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pyfda.plot_widgets.tran

Submodules
----------

pyfda.plot\_widgets.mpl\_widget module
--------------------------------------

.. automodule:: pyfda.plot_widgets.mpl_widget
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_3d module
-----------------------------------

.. automodule:: pyfda.plot_widgets.plot_3d
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_fft\_win module
-----------------------------------------

.. automodule:: pyfda.plot_widgets.plot_fft_win
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_hf module
-----------------------------------

.. automodule:: pyfda.plot_widgets.plot_hf
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_impz module
-------------------------------------

.. automodule:: pyfda.plot_widgets.plot_impz
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_impz\_ui module
-----------------------------------------

.. automodule:: pyfda.plot_widgets.plot_impz_ui
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_phi module
------------------------------------

.. automodule:: pyfda.plot_widgets.plot_phi
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_pz module
-----------------------------------

.. automodule:: pyfda.plot_widgets.plot_pz
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_tab\_widgets module
---------------------------------------------

.. automodule:: pyfda.plot_widgets.plot_tab_widgets
   :members:
   :undoc-members:
   :show-inheritance:

pyfda.plot\_widgets.plot\_tau\_g module
---------------------------------------

.. automodule:: pyfda.plot_widgets.plot_tau_g
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pyfda.plot_widgets
   :members:
   :undoc-members:
   :show-inheritance:
