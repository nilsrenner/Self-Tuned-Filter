"""
:mod:`pyfda.filter_widgets.bessel`
----------------------------------

.. automodule:: pyfda.filter_widgets.bessel
    :members:

.. comment automodule:: filter_widgets.butter

.. comment automodule:: filter_widgets.cheby1
"""
