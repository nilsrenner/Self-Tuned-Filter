Model-Reference Adaptive Control (MRAC) SISO, direct Lyapunov rule
------------------------------------------------------------------

Code
....
.. literalinclude:: mrac_siso_lyapunov.py
   :language: python
   :linenos:


Notes
.....

1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.