.. _steering-optimal:

Optimal control for vehicle steering (lane change)
---------------------------------------------------

Code
....
.. literalinclude:: steering-optimal.py
   :language: python
   :linenos:


Notes
.....
