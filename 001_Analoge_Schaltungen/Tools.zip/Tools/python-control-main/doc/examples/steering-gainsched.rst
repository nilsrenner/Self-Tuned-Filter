.. _steering-gainsched.py:

Gain scheduled control for vehicle steeering (I/O system)
---------------------------------------------------------

Code
....
.. literalinclude:: steering-gainsched.py
   :language: python
   :linenos:


Notes
.....
