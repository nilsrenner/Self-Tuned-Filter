ERA example, mass spring damper system
--------------------------------------

Code
....
.. literalinclude:: era_msd.py
   :language: python
   :linenos:


Notes
.....

1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.0