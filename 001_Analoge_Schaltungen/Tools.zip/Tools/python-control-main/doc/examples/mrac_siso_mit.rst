Model-Reference Adaptive Control (MRAC) SISO, direct MIT rule
-------------------------------------------------------------

Code
....
.. literalinclude:: mrac_siso_mit.py
   :language: python
   :linenos:


Notes
.....

1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.0