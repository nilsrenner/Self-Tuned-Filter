Hinf synthesis, based on Scherer et al. 1997 example 7
------------------------------------------------------

Code
....
.. literalinclude:: scherer_etal_ex7_Hinf_hinfsyn.py
   :language: python
   :linenos:


Notes
.....

1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
