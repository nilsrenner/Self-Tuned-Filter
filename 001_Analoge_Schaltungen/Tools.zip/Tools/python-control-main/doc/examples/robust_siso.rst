SISO robust control example (SP96, Example 2.1)
-----------------------------------------------

Code
....
.. literalinclude:: robust_siso.py
   :language: python
   :linenos:


Notes
.....
1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
