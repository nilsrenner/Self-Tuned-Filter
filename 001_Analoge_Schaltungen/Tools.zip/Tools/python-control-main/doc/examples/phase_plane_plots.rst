Phase  plot examples
--------------------

Code
....
.. literalinclude:: phase_plane_plots.py
   :language: python
   :linenos:


Notes
.....
1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
