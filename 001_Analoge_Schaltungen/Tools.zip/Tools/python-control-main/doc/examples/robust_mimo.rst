MIMO robust control example (SP96, Example 3.8)
-----------------------------------------------

Code
....
.. literalinclude:: robust_mimo.py
   :language: python
   :linenos:


Notes
.....
1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
