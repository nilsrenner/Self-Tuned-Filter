Cruise control design example (as a nonlinear I/O system)
---------------------------------------------------------

Code
....
.. literalinclude:: cruise-control.py
   :language: python
   :linenos:


Notes
.....
1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
