Balanced model reduction examples
---------------------------------

Code
....
.. literalinclude:: rss-balred.py
   :language: python
   :linenos:


Notes
.....

1. The environment variable `PYCONTROL_TEST_EXAMPLES` is used for
testing to turn off plotting of the outputs.
