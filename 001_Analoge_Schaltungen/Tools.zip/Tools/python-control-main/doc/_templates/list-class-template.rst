{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :members: plot
   :no-inherited-members:
   :show-inheritance:
